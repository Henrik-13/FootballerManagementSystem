﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2
{
    public partial class Form1 : Form
    {
        private CountriesDAL countriesDAL;
        private FootballersDAL footballersDAL;
        private string errMess;
        private int errNumber;

        public Form1()
        {
            InitializeComponent();
            string error = string.Empty;
            footballersDAL = new FootballersDAL(ref error);
            if (error != "OK")
            {
                errNumber = 1;
                errMess = "Error" + errNumber + Environment.NewLine + "Footballers objektumot nem tudtam letrehozni. " +
                          error;
            }
            else
            {
                errMess = "OK";
                countriesDAL = new CountriesDAL();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (errMess == "OK")
            {
                FillCbCountries();
                FillDgvFootballers(-1, null);
            }
        }

        private void FillCbCountries()
        {
            string error = string.Empty;
            List<Country> countryList = countriesDAL.GetCountryList(ref error);

            if (error != "OK")
            {
                errNumber++;
                if (errMess == "OK")
                {
                    errMess = string.Empty;
                }

                errMess = errMess + Environment.NewLine + "Error" + errNumber + Environment.NewLine + "" +
                          "Hiba a ComboBox feltoltesenel." + error;
            }
            else
            {
                cbCountries.DataSource = countryList;
                cbCountries.DisplayMember = "CountryName";
                cbCountries.ValueMember = "CountryID";
            }
        }

        private void FillDgvFootballers(int countryID, string name)
        {
            string error = string.Empty;
            dgvFootballers.Rows.Clear();
            List<Footballer> footballerList = footballersDAL.GetFootballerListDataSet(countryID, name, ref error);

            if (footballerList.Count != 0 && error == "OK")
            {
                foreach (Footballer item in footballerList)
                {
                    try
                    {
                        dgvFootballers.Rows.Add(item.FootballerID,
                            item.FootballerName,
                            item.Country.CountryID,
                            item.Country.CountryName,
                            item.Goals,
                            item.Assists,
                            item.Age,
                            item.CurrentValue);
                    }
                    catch (Exception ex)
                    {
                        errNumber++;
                        if (errMess == "OK")
                        {
                            errMess = string.Empty;
                        }

                        errMess = errMess + Environment.NewLine + "Error" +
                                  errNumber + Environment.NewLine + "Invalid data " + ex.Message;
                    }
                }
            }
            else if (error != "OK")
            {
                errNumber++;
                if (errMess == "OK")
                {
                    errMess = string.Empty;
                }
                errMess = errMess + Environment.NewLine +
                          "Error" + errNumber + Environment.NewLine + "Hiba a DataGridView feltoltesenel." + error;
            }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            if (errMess != "OK")
            {
                ErrorForm errorForm = new ErrorForm(errMess);
                errorForm.Show();
                errorForm.Focus();
            }
        }

        private void btFilter_Click(object sender, EventArgs e)
        {
            FillDgvFootballers(Convert.ToInt32(cbCountries.SelectedValue), tbNames.Text);
            if (errMess != "OK")
            {

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbCountries_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void dgvFootballers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bt_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
