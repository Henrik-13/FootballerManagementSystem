﻿using System.Windows.Forms;

namespace lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbNames = new System.Windows.Forms.TextBox();
            this.cbCountries = new System.Windows.Forms.ComboBox();
            this.bt_filter = new System.Windows.Forms.Button();
            this.dgvFootballers = new System.Windows.Forms.DataGridView();
            this.footballerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.footballerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goals = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assists = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.currentValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbCountry = new System.Windows.Forms.Label();
            this.lbName = new System.Windows.Forms.Label();
            this.bt_exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFootballers)).BeginInit();
            this.SuspendLayout();
            // 
            // tbNames
            // 
            this.tbNames.Location = new System.Drawing.Point(83, 58);
            this.tbNames.Name = "tbNames";
            this.tbNames.Size = new System.Drawing.Size(100, 22);
            this.tbNames.TabIndex = 0;
            this.tbNames.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // cbCountries
            // 
            this.cbCountries.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCountries.FormattingEnabled = true;
            this.cbCountries.Location = new System.Drawing.Point(221, 56);
            this.cbCountries.Name = "cbCountries";
            this.cbCountries.Size = new System.Drawing.Size(121, 24);
            this.cbCountries.TabIndex = 1;
            this.cbCountries.SelectedIndexChanged += new System.EventHandler(this.cbCountries_SelectedIndexChanged);
            // 
            // bt_filter
            // 
            this.bt_filter.Location = new System.Drawing.Point(454, 44);
            this.bt_filter.Name = "bt_filter";
            this.bt_filter.Size = new System.Drawing.Size(75, 23);
            this.bt_filter.TabIndex = 2;
            this.bt_filter.Text = "Szures";
            this.bt_filter.UseVisualStyleBackColor = true;
            this.bt_filter.Click += new System.EventHandler(this.btFilter_Click);
            // 
            // dgvFootballers
            // 
            this.dgvFootballers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFootballers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.footballerID,
            this.footballerName,
            this.countryID,
            this.countryName,
            this.goals,
            this.assists,
            this.age,
            this.currentValue});
            this.dgvFootballers.Location = new System.Drawing.Point(12, 95);
            this.dgvFootballers.Name = "dgvFootballers";
            this.dgvFootballers.ReadOnly = true;
            this.dgvFootballers.RowHeadersWidth = 51;
            this.dgvFootballers.RowTemplate.Height = 24;
            this.dgvFootballers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFootballers.Size = new System.Drawing.Size(748, 263);
            this.dgvFootballers.TabIndex = 26;
            this.dgvFootballers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFootballers_CellContentClick);
            // 
            // footballerID
            // 
            this.footballerID.HeaderText = "ID";
            this.footballerID.MinimumWidth = 6;
            this.footballerID.Name = "footballerID";
            this.footballerID.ReadOnly = true;
            this.footballerID.Visible = false;
            this.footballerID.Width = 125;
            // 
            // footballerName
            // 
            this.footballerName.HeaderText = "Nev";
            this.footballerName.MinimumWidth = 6;
            this.footballerName.Name = "footballerName";
            this.footballerName.ReadOnly = true;
            this.footballerName.Width = 125;
            // 
            // countryID
            // 
            this.countryID.HeaderText = "OrszagID";
            this.countryID.MinimumWidth = 6;
            this.countryID.Name = "countryID";
            this.countryID.ReadOnly = true;
            this.countryID.Visible = false;
            this.countryID.Width = 125;
            // 
            // countryName
            // 
            this.countryName.HeaderText = "Orszag";
            this.countryName.MinimumWidth = 6;
            this.countryName.Name = "countryName";
            this.countryName.ReadOnly = true;
            this.countryName.Width = 125;
            // 
            // goals
            // 
            this.goals.HeaderText = "Golok";
            this.goals.MinimumWidth = 6;
            this.goals.Name = "goals";
            this.goals.ReadOnly = true;
            this.goals.Width = 125;
            // 
            // assists
            // 
            this.assists.HeaderText = "Golpasszok";
            this.assists.MinimumWidth = 6;
            this.assists.Name = "assists";
            this.assists.ReadOnly = true;
            this.assists.Width = 125;
            // 
            // age
            // 
            this.age.HeaderText = "Eletkor";
            this.age.MinimumWidth = 6;
            this.age.Name = "age";
            this.age.ReadOnly = true;
            this.age.Width = 125;
            // 
            // currentValue
            // 
            this.currentValue.HeaderText = "Ertek";
            this.currentValue.MinimumWidth = 6;
            this.currentValue.Name = "currentValue";
            this.currentValue.ReadOnly = true;
            this.currentValue.Width = 125;
            // 
            // lbCountry
            // 
            this.lbCountry.AutoSize = true;
            this.lbCountry.Location = new System.Drawing.Point(254, 25);
            this.lbCountry.Name = "lbCountry";
            this.lbCountry.Size = new System.Drawing.Size(83, 16);
            this.lbCountry.TabIndex = 27;
            this.lbCountry.Text = "Orszag neve";
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Location = new System.Drawing.Point(101, 25);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(88, 16);
            this.lbName.TabIndex = 28;
            this.lbName.Text = "Jatekos neve";
            // 
            // bt_exit
            // 
            this.bt_exit.Location = new System.Drawing.Point(645, 382);
            this.bt_exit.Name = "bt_exit";
            this.bt_exit.Size = new System.Drawing.Size(75, 23);
            this.bt_exit.TabIndex = 29;
            this.bt_exit.Text = "Kilep";
            this.bt_exit.UseVisualStyleBackColor = true;
            this.bt_exit.Click += new System.EventHandler(this.bt_exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt_exit);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.lbCountry);
            this.Controls.Add(this.dgvFootballers);
            this.Controls.Add(this.bt_filter);
            this.Controls.Add(this.cbCountries);
            this.Controls.Add(this.tbNames);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFootballers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbNames;
        private System.Windows.Forms.ComboBox cbCountries;
        private System.Windows.Forms.Button bt_filter;
        private System.Windows.Forms.DataGridView dgvFootballers;
        private System.Windows.Forms.Label lbCountry;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.DataGridViewTextBoxColumn footballerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn footballerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn countryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn countryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn goals;
        private System.Windows.Forms.DataGridViewTextBoxColumn assists;
        private System.Windows.Forms.DataGridViewTextBoxColumn age;
        private System.Windows.Forms.DataGridViewTextBoxColumn currentValue;
        private Button bt_exit;
    }
}

